# TVMaze Explorer — Flutter + BLoC

A TV show discovery app powered by the public [TVMaze API](https://api.tvmaze.com). The app uses `flutter_bloc` for feature state management and `SharedPreferences` to persist the watchlist locally.

## Features
- Discover shows from `/shows?page=0`, with pagination as you scroll.
- Search TVMaze dynamically with a 400 ms debounce.
- Show details, summary, poster, genres, rating, status, network and language.
- Load cast and episodes from the TVMaze endpoints; episodes can be filtered by season.
- Add/remove shows from a persistent local watchlist.
- Loading, empty, retry and API error states; missing images/metadata use graceful fallbacks.
- API/data logic is separated from UI widgets.

## Project structure
```text
lib/
  main.dart
  models/tv_show.dart
  data/tvmaze_repository.dart
  logic/
    shows_bloc.dart
    search_bloc.dart
    details_bloc.dart
    watchlist_cubit.dart
  ui/
    app_shell.dart
    home_screen.dart
    search_screen.dart
    show_details_screen.dart
    watchlist_screen.dart
    widgets/
      show_poster_card.dart
      show_list_tile.dart
```

## Run on your computer
1. Install Flutter and Android Studio (or configure a device/emulator).
2. Extract this ZIP.
3. Open a terminal in the extracted `tvmaze_flutter_app` directory.
4. Run:
   ```bash
   flutter pub get
   flutter run
   ```
5. For a Windows desktop build, enable desktop support if required and run `flutter run -d windows`.

## API endpoints used
- Shows and pagination: `GET https://api.tvmaze.com/shows?page={page}`
- Search: `GET https://api.tvmaze.com/search/shows?q={query}`
- Details: `GET https://api.tvmaze.com/shows/{id}`
- Cast: `GET https://api.tvmaze.com/shows/{id}/cast`
- Episodes: `GET https://api.tvmaze.com/shows/{id}/episodes`

## Notes
- The API is public and does not require an API key. Network access is required.
- TVMaze show pages can be large; the app requests pages as needed.
- Watchlist metadata is saved in the device's SharedPreferences. It is not synced between devices.
- If you target Android and network access is blocked by a custom manifest, ensure the app has the `INTERNET` permission. Flutter's standard Android template normally includes it.
