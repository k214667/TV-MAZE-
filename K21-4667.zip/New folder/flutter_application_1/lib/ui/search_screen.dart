import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../logic/search_bloc.dart';
import 'widgets/show_list_tile.dart';

class SearchScreen extends StatelessWidget {
  const SearchScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('Search shows', style: TextStyle(fontWeight: FontWeight.w800))),
    body: Column(children: [
      Padding(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: TextField(
          onChanged: (query) => context.read<SearchBloc>().add(SearchQueryChanged(query)),
          decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search by show name'),
        ),
      ),
      Expanded(child: BlocBuilder<SearchBloc, SearchState>(builder: (context, state) {
        switch (state.status) {
          case SearchStatus.idle:
            return const _Message(icon: Icons.travel_explore, text: 'Search for a TV show to get started.');
          case SearchStatus.loading:
            return const Center(child: CircularProgressIndicator());
          case SearchStatus.empty:
            return const _Message(icon: Icons.search_off, text: 'No shows found. Try another search.');
          case SearchStatus.failure:
            return _Message(icon: Icons.cloud_off, text: state.error);
          case SearchStatus.success:
            return ListView.builder(itemCount: state.results.length, itemBuilder: (_, i) => ShowListTile(show: state.results[i]));
        }
      })),
    ]),
  );
}
class _Message extends StatelessWidget {
  const _Message({required this.icon, required this.text});
  final IconData icon;
  final String text;
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      Icon(icon, size: 48, color: const Color(0xFF9B83FF)),
      const SizedBox(height: 12),
      Text(text, textAlign: TextAlign.center),
    ]),
  ));
}
