import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../logic/shows_bloc.dart';
import 'widgets/show_poster_card.dart';
import 'widgets/show_list_tile.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}
class _HomeScreenState extends State<HomeScreen> {
  final _scrollController = ScrollController();
  @override
  void initState() {
    super.initState();
    _scrollController.addListener(_onScroll);
  }
  void _onScroll() {
    if (_scrollController.position.pixels >= _scrollController.position.maxScrollExtent - 350) {
      context.read<ShowsBloc>().add(const MoreShowsRequested());
    }
  }
  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('TVMaze Explorer', style: TextStyle(fontWeight: FontWeight.w800)), actions: [
      IconButton(onPressed: () => context.read<ShowsBloc>().add(const ShowsRefreshed()), icon: const Icon(Icons.refresh)),
    ]),
    body: BlocBuilder<ShowsBloc, ShowsState>(
      builder: (context, state) {
        if (state.status == ShowsStatus.loading && state.shows.isEmpty) return const Center(child: CircularProgressIndicator());
        if (state.status == ShowsStatus.failure && state.shows.isEmpty) return _ErrorView(message: state.error, onRetry: () => context.read<ShowsBloc>().add(const ShowsRequested()));
        if (state.shows.isEmpty) return const Center(child: Text('No shows are available right now.'));
        final featured = state.shows.take(12).toList();
        return RefreshIndicator(
          onRefresh: () async => context.read<ShowsBloc>().add(const ShowsRefreshed()),
          child: ListView(controller: _scrollController, padding: const EdgeInsets.fromLTRB(16, 12, 16, 24), children: [
            Text('Hello, TV Explorer! 👋', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
            const SizedBox(height: 5),
            Text('Discover your next favorite show.', style: TextStyle(color: Colors.white.withValues(alpha: .65))),
            const SizedBox(height: 24),
            const _SectionTitle(title: 'Explore shows'),
            const SizedBox(height: 12),
            SizedBox(height: 278, child: ListView.separated(
              scrollDirection: Axis.horizontal, itemCount: featured.length, separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => ShowPosterCard(show: featured[i]),
            )),
            const SizedBox(height: 22),
            const _SectionTitle(title: 'All TV shows'),
            const SizedBox(height: 8),
            ...state.shows.map((show) => ShowListTile(show: show)),
            if (state.status == ShowsStatus.loadingMore) const Padding(padding: EdgeInsets.all(20), child: Center(child: CircularProgressIndicator())),
            if (state.error.isNotEmpty) Padding(padding: const EdgeInsets.all(12), child: Text(state.error, style: const TextStyle(color: Colors.orangeAccent))),
            if (!state.hasMore) const Padding(padding: EdgeInsets.all(20), child: Center(child: Text('You have reached the end.'))),
          ]),
        );
      },
    ),
  );
}
class _SectionTitle extends StatelessWidget {
  const _SectionTitle({required this.title});
  final String title;
  @override
  Widget build(BuildContext context) => Text(title, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800));
}
class _ErrorView extends StatelessWidget {
  const _ErrorView({required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(24),
    child: Column(mainAxisSize: MainAxisSize.min, children: [
      const Icon(Icons.cloud_off, size: 48), const SizedBox(height: 12),
      Text(message, textAlign: TextAlign.center), const SizedBox(height: 16),
      FilledButton(onPressed: onRetry, child: const Text('Try again')),
    ]),
  ));
}
