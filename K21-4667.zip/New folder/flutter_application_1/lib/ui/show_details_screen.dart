import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../data/tvmaze_repository.dart';
import '../logic/details_bloc.dart';
import '../logic/watchlist_cubit.dart';
import '../models/tv_show.dart';

class ShowDetailsScreen extends StatelessWidget {
  const ShowDetailsScreen({super.key, required this.show});
  final TvShow show;

  @override
  Widget build(BuildContext context) => BlocProvider(
    create: (context) => DetailsBloc(context.read<TvMazeRepository>())..add(DetailsRequested(show.id)),
    child: _DetailsView(initialShow: show),
  );
}

class _DetailsView extends StatefulWidget {
  const _DetailsView({required this.initialShow});
  final TvShow initialShow;
  @override
  State<_DetailsView> createState() => _DetailsViewState();
}
class _DetailsViewState extends State<_DetailsView> {
  int _tab = 0;
  int? _season;
  @override
  Widget build(BuildContext context) => Scaffold(
    body: BlocBuilder<DetailsBloc, DetailsState>(builder: (context, state) {
      final show = state.show ?? widget.initialShow;
      if (state.status == DetailsStatus.loading && state.show == null) {
        return const Center(child: CircularProgressIndicator());
      }
      if (state.status == DetailsStatus.failure && state.show == null) {
        return Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(mainAxisSize: MainAxisSize.min, children: [
          Text(state.error, textAlign: TextAlign.center),
          const SizedBox(height: 12),
          FilledButton(onPressed: () => context.read<DetailsBloc>().add(DetailsRequested(show.id)), child: const Text('Retry')),
        ])));
      }
      final saved = context.watch<WatchlistCubit>().contains(show.id);
      final seasons = state.episodes.map((e) => e.season).toSet().toList()..sort();
      final selectedSeason = _season ?? (seasons.isEmpty ? 1 : seasons.first);
      return CustomScrollView(slivers: [
        SliverAppBar(pinned: true, expandedHeight: 310, title: Text(show.name, maxLines: 1, overflow: TextOverflow.ellipsis),
          actions: [IconButton(onPressed: () => context.read<WatchlistCubit>().toggle(show), icon: Icon(saved ? Icons.favorite : Icons.favorite_border, color: saved ? const Color(0xFFFF657A) : null))],
          flexibleSpace: FlexibleSpaceBar(background: Stack(fit: StackFit.expand, children: [
            if (show.imageUrl != null) Image.network(show.imageUrl!, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF252A40)))
            else const ColoredBox(color: Color(0xFF252A40)),
            const DecoratedBox(decoration: BoxDecoration(gradient: LinearGradient(begin: Alignment.topCenter, end: Alignment.bottomCenter, colors: [Colors.transparent, Color(0xFF0B0D16)], stops: [.25, 1]))),
            Positioned(left: 18, right: 18, bottom: 18, child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(show.name, style: const TextStyle(fontSize: 28, fontWeight: FontWeight.w900)),
              const SizedBox(height: 6),
              Text('${show.premiered?.substring(0, 4) ?? 'Year unknown'}${show.ended == null ? '' : ' – ${show.ended!.substring(0, 4)}'}  •  ${show.status ?? 'Status unknown'}'),
              if (show.rating != null) Text('★ ${show.rating!.toStringAsFixed(1)} / 10', style: const TextStyle(color: Color(0xFFFFD166))),
            ])),
          ])),
        ),
        SliverPadding(padding: const EdgeInsets.fromLTRB(16, 14, 16, 30), sliver: SliverList(delegate: SliverChildListDelegate([
          Wrap(spacing: 8, runSpacing: 8, children: show.genres.isEmpty ? [const Chip(label: Text('Genres unavailable'))] : show.genres.map((g) => Chip(label: Text(g))).toList()),
          const SizedBox(height: 12),
          Text(show.summary.isEmpty ? 'No summary is available for this show.' : show.summary, style: const TextStyle(height: 1.45)),
          const SizedBox(height: 20),
          SegmentedButton<int>(
            segments: const [
              ButtonSegment(value: 0, label: Text('Overview'), icon: Icon(Icons.info_outline)),
              ButtonSegment(value: 1, label: Text('Episodes'), icon: Icon(Icons.movie_outlined)),
              ButtonSegment(value: 2, label: Text('Cast'), icon: Icon(Icons.people_outline)),
            ],
            selected: {_tab}, onSelectionChanged: (v) => setState(() => _tab = v.first),
          ),
          const SizedBox(height: 16),
          if (_tab == 0) _InfoPanel(show: show)
          else if (_tab == 1) ...[
            if (state.status == DetailsStatus.loading) const LinearProgressIndicator(),
            if (state.episodes.isEmpty && state.status == DetailsStatus.success) const Text('No episode information is available.'),
            if (seasons.isNotEmpty) DropdownButtonFormField<int>(
              value: seasons.contains(selectedSeason) ? selectedSeason : seasons.first,
              decoration: const InputDecoration(labelText: 'Season'),
              items: seasons.map((s) => DropdownMenuItem(value: s, child: Text('Season $s'))).toList(),
              onChanged: (v) => setState(() => _season = v),
            ),
            ...state.episodes.where((e) => e.season == selectedSeason).map((episode) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: episode.imageUrl == null ? const Icon(Icons.play_circle_outline) : ClipRRect(borderRadius: BorderRadius.circular(8), child: Image.network(episode.imageUrl!, width: 74, height: 50, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.play_circle_outline))),
              title: Text('${episode.number}. ${episode.name}'),
              subtitle: Text('${episode.airdate ?? 'Air date unknown'}${episode.summary == null || episode.summary!.isEmpty ? '' : '\n${episode.summary}'}', maxLines: 3, overflow: TextOverflow.ellipsis),
            )),
          ] else ...[
            if (state.status == DetailsStatus.loading) const LinearProgressIndicator(),
            if (state.cast.isEmpty && state.status == DetailsStatus.success) const Text('No cast information is available.'),
            ...state.cast.map((member) => ListTile(
              contentPadding: EdgeInsets.zero,
              leading: CircleAvatar(
                backgroundImage: member.imageUrl == null ? null : NetworkImage(member.imageUrl!),
                child: member.imageUrl == null ? const Icon(Icons.person) : null,
              ),
              title: Text(member.name),
              subtitle: Text(member.character ?? 'Character unavailable'),
            )),
          ],
          if (state.error.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 12), child: Text(state.error, style: const TextStyle(color: Colors.orangeAccent))),
        ]))),
      ]);
    }),
  );
}

class _InfoPanel extends StatelessWidget {
  const _InfoPanel({required this.show});
  final TvShow show;
  @override
  Widget build(BuildContext context) {
    final rows = <MapEntry<String, String>>[
      MapEntry('Status', show.status ?? 'Unknown'),
      MapEntry('Network', show.network ?? 'Unknown'),
      MapEntry('Language', show.language ?? 'Unknown'),
      MapEntry('Premiered', show.premiered ?? 'Unknown'),
      MapEntry('Schedule', show.schedule.isEmpty ? 'Unknown' : show.schedule.join(', ')),
    ];
    return Card(child: Column(children: rows.map((row) => ListTile(
      dense: true, title: Text(row.key, style: TextStyle(color: Colors.white.withValues(alpha: .65), fontSize: 13)),
      trailing: SizedBox(width: 190, child: Text(row.value, textAlign: TextAlign.end, maxLines: 2, overflow: TextOverflow.ellipsis)),
    )).toList()));
  }
}
