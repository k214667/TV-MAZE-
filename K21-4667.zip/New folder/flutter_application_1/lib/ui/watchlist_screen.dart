import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../logic/watchlist_cubit.dart';
import '../models/tv_show.dart';
import 'widgets/show_list_tile.dart';

class WatchlistScreen extends StatelessWidget {
  const WatchlistScreen({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('My watchlist', style: TextStyle(fontWeight: FontWeight.w800))),
    body: BlocBuilder<WatchlistCubit, List<TvShow>>(
      builder: (context, rawShows) {
        final shows = rawShows;
        if (shows.isEmpty) {
          return Center(child: Padding(
            padding: const EdgeInsets.all(28),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Icon(Icons.favorite_border, size: 64, color: Color(0xFF9B83FF)),
              const SizedBox(height: 16),
              const Text('Your watchlist is empty', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w800)),
              const SizedBox(height: 8),
              Text('Explore shows and tap the heart to save them here.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white.withValues(alpha: .7))),
            ]),
          ));
        }
        return ListView.builder(
          itemCount: shows.length,
          itemBuilder: (_, index) {
            final show = shows[index];
            return ShowListTile(
              show: show,
              trailing: IconButton(
                tooltip: 'Remove from watchlist',
                icon: const Icon(Icons.favorite, color: Color(0xFFFF657A)),
                onPressed: () => context.read<WatchlistCubit>().remove(show.id),
              ),
            );
          },
        );
      },
    ),
  );
}
