import 'package:flutter/material.dart';
import '../../models/tv_show.dart';
import '../show_details_screen.dart';

class ShowPosterCard extends StatelessWidget {
  const ShowPosterCard({super.key, required this.show});
  final TvShow show;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShowDetailsScreen(show: show))),
      child: SizedBox(
        width: 142,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: AspectRatio(
              aspectRatio: 0.70,
              child: show.imageUrl == null
                  ? const _PosterPlaceholder()
                  : Image.network(show.imageUrl!, fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const _PosterPlaceholder(),
                      loadingBuilder: (context, child, progress) => progress == null ? child : const _PosterPlaceholder()),
            ),
          ),
          const SizedBox(height: 8),
          Text(show.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
          Text(show.genres.isEmpty ? 'Genre unavailable' : show.genres.take(2).join(', '),
              maxLines: 1, overflow: TextOverflow.ellipsis, style: TextStyle(color: Colors.white.withValues(alpha: .65), fontSize: 12)),
          if (show.rating != null) Text('★ ${show.rating!.toStringAsFixed(1)}', style: const TextStyle(color: Color(0xFFFFD166), fontSize: 12)),
        ]),
      ),
    );
  }
}
class _PosterPlaceholder extends StatelessWidget {
  const _PosterPlaceholder();
  @override
  Widget build(BuildContext context) => Container(
    color: const Color(0xFF252A40),
    child: const Center(child: Icon(Icons.live_tv, size: 42, color: Color(0xFF9B83FF))),
  );
}
