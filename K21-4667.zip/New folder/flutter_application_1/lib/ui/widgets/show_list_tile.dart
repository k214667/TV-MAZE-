import 'package:flutter/material.dart';
import '../../models/tv_show.dart';
import '../show_details_screen.dart';

class ShowListTile extends StatelessWidget {
  const ShowListTile({super.key, required this.show, this.trailing});
  final TvShow show;
  final Widget? trailing;
  @override
  Widget build(BuildContext context) => ListTile(
    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 5),
    leading: ClipRRect(
      borderRadius: BorderRadius.circular(9),
      child: SizedBox(width: 56, height: 76, child: show.imageUrl == null
          ? const ColoredBox(color: Color(0xFF252A40), child: Icon(Icons.live_tv))
          : Image.network(show.imageUrl!, fit: BoxFit.cover,
              errorBuilder: (_, __, ___) => const ColoredBox(color: Color(0xFF252A40), child: Icon(Icons.live_tv)),
              loadingBuilder: (_, child, progress) => progress == null ? child : const ColoredBox(color: Color(0xFF252A40), child: Icon(Icons.live_tv)))),
    ),
    title: Text(show.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700)),
    subtitle: Padding(
      padding: const EdgeInsets.only(top: 4),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text([show.premiered?.substring(0, 4), show.ended?.substring(0, 4)].whereType<String>().join(' – ')),
        Text(show.genres.isEmpty ? 'Genres unavailable' : show.genres.join(', '), maxLines: 1, overflow: TextOverflow.ellipsis),
        if (show.rating != null) Text('★ ${show.rating!.toStringAsFixed(1)} / 10', style: const TextStyle(color: Color(0xFFFFD166))),
      ]),
    ),
    trailing: trailing ?? const Icon(Icons.chevron_right),
    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ShowDetailsScreen(show: show))),
  );
}
