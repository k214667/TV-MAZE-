import 'package:equatable/equatable.dart';

String _cleanHtml(dynamic value) {
  if (value == null) return '';
  return value.toString()
      .replaceAll(RegExp(r'<[^>]*>'), ' ')
      .replaceAll('&nbsp;', ' ')
      .replaceAll('&amp;', '&')
      .replaceAll('&quot;', '"')
      .replaceAll('&#39;', "'")
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

class TvShow extends Equatable {
  const TvShow({
    required this.id,
    required this.name,
    this.summary = '',
    this.imageUrl,
    this.genres = const [],
    this.rating,
    this.premiered,
    this.ended,
    this.status,
    this.network,
    this.language,
    this.schedule = const [],
    this.officialSite,
  });

  final int id;
  final String name;
  final String summary;
  final String? imageUrl;
  final List<String> genres;
  final double? rating;
  final String? premiered;
  final String? ended;
  final String? status;
  final String? network;
  final String? language;
  final List<String> schedule;
  final String? officialSite;

  factory TvShow.fromJson(Map<String, dynamic> json) {
    final image = json['image'] as Map<String, dynamic>?;
    final ratingMap = json['rating'] as Map<String, dynamic>?;
    final networkMap = json['network'] as Map<String, dynamic>?;
    final webChannelMap = json['webChannel'] as Map<String, dynamic>?;
    final scheduleMap = json['schedule'] as Map<String, dynamic>?;
    final rawDays = scheduleMap?['days'];
    return TvShow(
      id: (json['id'] as num?)?.toInt() ?? 0,
      name: json['name']?.toString() ?? 'Untitled show',
      summary: _cleanHtml(json['summary']),
      imageUrl: (image?['original'] ?? image?['medium'])?.toString(),
      genres: (json['genres'] as List? ?? []).map((e) => e.toString()).toList(),
      rating: (ratingMap?['average'] as num?)?.toDouble(),
      premiered: json['premiered']?.toString(),
      ended: json['ended']?.toString(),
      status: json['status']?.toString(),
      network: (networkMap?['name'] ?? webChannelMap?['name'])?.toString(),
      language: json['language']?.toString(),
      schedule: rawDays is List ? rawDays.map((e) => e.toString()).toList() : const [],
      officialSite: json['officialSite']?.toString(),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id, 'name': name, 'summary': summary, 'imageUrl': imageUrl,
    'genres': genres, 'rating': rating, 'premiered': premiered, 'ended': ended,
    'status': status, 'network': network, 'language': language,
    'schedule': schedule, 'officialSite': officialSite,
  };

  factory TvShow.fromStoredJson(Map<String, dynamic> json) => TvShow(
    id: (json['id'] as num?)?.toInt() ?? 0,
    name: json['name']?.toString() ?? 'Untitled show',
    summary: json['summary']?.toString() ?? '',
    imageUrl: json['imageUrl']?.toString(),
    genres: (json['genres'] as List? ?? []).map((e) => e.toString()).toList(),
    rating: (json['rating'] as num?)?.toDouble(),
    premiered: json['premiered']?.toString(),
    ended: json['ended']?.toString(),
    status: json['status']?.toString(),
    network: json['network']?.toString(),
    language: json['language']?.toString(),
    schedule: (json['schedule'] as List? ?? []).map((e) => e.toString()).toList(),
    officialSite: json['officialSite']?.toString(),
  );

  @override
  List<Object?> get props => [id, name, summary, imageUrl, genres, rating, premiered, ended, status, network, language, schedule, officialSite];
}

class CastMember extends Equatable {
  const CastMember({
    required this.name,
    this.character,
    this.imageUrl,
  });

  final String name;
  final String? character;
  final String? imageUrl;

  factory CastMember.fromJson(Map<String, dynamic> json) {
    final person = json['person'] as Map<String, dynamic>? ?? {};
    final character = json['character'] as Map<String, dynamic>? ?? {};
    final image =
        (person['image'] ?? character['image']) as Map<String, dynamic>?;

    return CastMember(
      name: person['name']?.toString() ?? 'Unknown performer',
      character: character['name']?.toString(),
      imageUrl: (image?['medium'] ?? image?['original'])?.toString(),
    );
  }

  @override
  List<Object?> get props => [
        name,
        character,
        imageUrl,
      ];
}

class TvEpisode {
  const TvEpisode({required this.id, required this.name, required this.season, required this.number, this.airdate, this.summary, this.imageUrl});
  final int id;
  final String name;
  final int season;
  final int number;
  final String? airdate;
  final String? summary;
  final String? imageUrl;

  factory TvEpisode.fromJson(Map<String, dynamic> json) {
    final image = json['image'] as Map<String, dynamic>?;
    return TvEpisode(
      id: (json['id'] as num?)?.toInt() ?? 0,
      name: json['name']?.toString() ?? 'Untitled episode',
      season: (json['season'] as num?)?.toInt() ?? 0,
      number: (json['number'] as num?)?.toInt() ?? 0,
      airdate: json['airdate']?.toString(),
      summary: json['summary']?.toString().replaceAll(RegExp(r'<[^>]*>'), ' ').trim(),
      imageUrl: (image?['medium'] ?? image?['original'])?.toString(),
    );
  }
}
