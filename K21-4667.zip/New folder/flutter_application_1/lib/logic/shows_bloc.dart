import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../data/tvmaze_repository.dart';
import '../models/tv_show.dart';

abstract class ShowsEvent extends Equatable {
  const ShowsEvent();
  @override
  List<Object?> get props => [];
}
class ShowsRequested extends ShowsEvent { const ShowsRequested(); }
class MoreShowsRequested extends ShowsEvent { const MoreShowsRequested(); }
class ShowsRefreshed extends ShowsEvent { const ShowsRefreshed(); }

enum ShowsStatus { initial, loading, success, failure, loadingMore }

class ShowsState extends Equatable {
  const ShowsState({this.status = ShowsStatus.initial, this.shows = const [], this.page = 0, this.hasMore = true, this.error = ''});
  final ShowsStatus status;
  final List<TvShow> shows;
  final int page;
  final bool hasMore;
  final String error;
  ShowsState copyWith({ShowsStatus? status, List<TvShow>? shows, int? page, bool? hasMore, String? error}) =>
      ShowsState(status: status ?? this.status, shows: shows ?? this.shows, page: page ?? this.page, hasMore: hasMore ?? this.hasMore, error: error ?? this.error);
  @override
  List<Object?> get props => [status, shows, page, hasMore, error];
}

class ShowsBloc extends Bloc<ShowsEvent, ShowsState> {
  ShowsBloc(this.repository) : super(const ShowsState()) {
    on<ShowsRequested>((event, emit) => _loadFirst(emit));
    on<ShowsRefreshed>((event, emit) => _loadFirst(emit));
    on<MoreShowsRequested>(_loadMore);
  }
  final TvMazeRepository repository;

  Future<void> _loadFirst(Emitter<ShowsState> emit) async {
    emit(state.copyWith(status: ShowsStatus.loading, error: ''));
    try {
      final shows = await repository.getShows(0);
      emit(state.copyWith(status: ShowsStatus.success, shows: shows, page: 0, hasMore: shows.isNotEmpty, error: ''));
    } catch (e) {
      emit(state.copyWith(status: ShowsStatus.failure, error: e.toString()));
    }
  }

  Future<void> _loadMore(MoreShowsRequested event, Emitter<ShowsState> emit) async {
    if (state.status == ShowsStatus.loadingMore || state.status == ShowsStatus.loading || !state.hasMore) return;
    emit(state.copyWith(status: ShowsStatus.loadingMore));
    try {
      final nextPage = state.page + 1;
      final next = await repository.getShows(nextPage);
      emit(state.copyWith(status: ShowsStatus.success, shows: [...state.shows, ...next], page: nextPage, hasMore: next.isNotEmpty));
    } catch (e) {
      emit(state.copyWith(status: ShowsStatus.success, error: e.toString()));
    }
  }
}
