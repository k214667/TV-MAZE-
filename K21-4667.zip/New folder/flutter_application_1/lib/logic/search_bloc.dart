import 'dart:async';
import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../data/tvmaze_repository.dart';
import '../models/tv_show.dart';

abstract class SearchEvent extends Equatable {
  const SearchEvent();
  @override
  List<Object?> get props => [];
}
class SearchQueryChanged extends SearchEvent {
  const SearchQueryChanged(this.query);
  final String query;
  @override
  List<Object?> get props => [query];
}
enum SearchStatus { idle, loading, success, empty, failure }
class SearchState extends Equatable {
  const SearchState({this.status = SearchStatus.idle, this.query = '', this.results = const [], this.error = ''});
  final SearchStatus status;
  final String query;
  final List<TvShow> results;
  final String error;
  @override
  List<Object?> get props => [status, query, results, error];
}
class SearchBloc extends Bloc<SearchEvent, SearchState> {
  SearchBloc(this.repository) : super(const SearchState()) {
    on<SearchQueryChanged>(_onQueryChanged);
  }
  final TvMazeRepository repository;
  Timer? _debounce;
  int _requestToken = 0;

  Future<void> _onQueryChanged(SearchQueryChanged event, Emitter<SearchState> emit) async {
    final query = event.query.trim();
    _debounce?.cancel();
    final token = ++_requestToken;
    if (query.isEmpty) {
      emit(const SearchState());
      return;
    }
    emit(SearchState(status: SearchStatus.loading, query: query));
    await Future<void>.delayed(const Duration(milliseconds: 400));
    if (emit.isDone || token != _requestToken) return;
    try {
      final results = await repository.searchShows(query);
      if (!emit.isDone && token == _requestToken) {
        emit(SearchState(status: results.isEmpty ? SearchStatus.empty : SearchStatus.success, query: query, results: results));
      }
    } catch (e) {
      if (!emit.isDone && token == _requestToken) {
        emit(SearchState(status: SearchStatus.failure, query: query, error: e.toString()));
      }
    }
  }

  @override
  Future<void> close() {
    _debounce?.cancel();
    return super.close();
  }
}
