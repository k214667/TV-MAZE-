import 'package:bloc/bloc.dart';
import 'package:equatable/equatable.dart';
import '../data/tvmaze_repository.dart';
import '../models/tv_show.dart';

abstract class DetailsEvent extends Equatable {
  const DetailsEvent();
  @override
  List<Object?> get props => [];
}
class DetailsRequested extends DetailsEvent {
  const DetailsRequested(this.showId);
  final int showId;
  @override
  List<Object?> get props => [showId];
}
enum DetailsStatus { initial, loading, success, failure }
class DetailsState extends Equatable {
  const DetailsState({this.status = DetailsStatus.initial, this.show, this.cast = const [], this.episodes = const [], this.error = ''});
  final DetailsStatus status;
  final TvShow? show;
  final List<CastMember> cast;
  final List<TvEpisode> episodes;
  final String error;
  @override
  List<Object?> get props => [status, show, cast, episodes, error];
}
class DetailsBloc extends Bloc<DetailsEvent, DetailsState> {
  DetailsBloc(this.repository) : super(const DetailsState()) {
    on<DetailsRequested>(_load);
  }
  final TvMazeRepository repository;
  Future<void> _load(DetailsRequested event, Emitter<DetailsState> emit) async {
    emit(const DetailsState(status: DetailsStatus.loading));
    try {
      final results = await Future.wait<dynamic>([
        repository.getShow(event.showId),
        repository.getCast(event.showId),
        repository.getEpisodes(event.showId),
      ]);
      emit(DetailsState(status: DetailsStatus.success, show: results[0] as TvShow, cast: results[1] as List<CastMember>, episodes: results[2] as List<TvEpisode>));
    } catch (e) {
      emit(DetailsState(status: DetailsStatus.failure, error: e.toString()));
    }
  }
}
