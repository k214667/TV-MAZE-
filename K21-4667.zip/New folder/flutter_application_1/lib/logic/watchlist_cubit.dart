import 'dart:convert';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/tv_show.dart';

class WatchlistCubit extends Cubit<List<TvShow>> {
  WatchlistCubit() : super(const []);
  static const _storageKey = 'tvmaze_watchlist_v1';

  Future<void> load() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) return;
      final list = jsonDecode(raw) as List;
      emit(list.whereType<Map<String, dynamic>>().map(TvShow.fromStoredJson).toList());
    } catch (_) {
      // Corrupt or unavailable local storage should not crash the app.
      emit(const []);
    }
  }

  bool contains(int id) => state.any((show) => show.id == id);

  Future<void> toggle(TvShow show) async {
    final updated = contains(show.id)
        ? state.where((item) => item.id != show.id).toList()
        : [...state, show];
    emit(updated);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_storageKey, jsonEncode(updated.map((item) => item.toJson()).toList()));
    } catch (_) {
      // Keep the current session usable if local storage fails.
    }
  }

  Future<void> remove(int id) async {
    final updated = state.where((show) => show.id != id).toList();
    emit(updated);
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_storageKey, jsonEncode(updated.map((item) => item.toJson()).toList()));
    } catch (_) {}
  }
}
