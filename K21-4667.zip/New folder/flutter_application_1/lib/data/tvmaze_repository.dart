import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/tv_show.dart';

class TvMazeException implements Exception {
  TvMazeException(this.message);
  final String message;
  @override
  String toString() => message;
}

class TvMazeRepository {
  TvMazeRepository({http.Client? client}) : _client = client ?? http.Client();
  final http.Client _client;
  static const _base = 'https://api.tvmaze.com';

  Future<dynamic> _get(String path) async {
    try {
      final response = await _client.get(Uri.parse('$_base$path')).timeout(const Duration(seconds: 15));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw TvMazeException('The TVMaze service returned ${response.statusCode}. Please try again.');
      }
      return jsonDecode(response.body);
    } on TvMazeException {
      rethrow;
    } catch (_) {
      throw TvMazeException('Could not connect to TVMaze. Check your internet connection and try again.');
    }
  }

  Future<List<TvShow>> getShows(int page) async {
    final data = await _get('/shows?page=$page');
    if (data is! List) throw TvMazeException('Unexpected response from TVMaze.');
    return data.whereType<Map<String, dynamic>>().map(TvShow.fromJson).toList();
  }

  Future<List<TvShow>> searchShows(String query) async {
    final data = await _get('/search/shows?q=${Uri.encodeQueryComponent(query)}');
    if (data is! List) throw TvMazeException('Unexpected search response from TVMaze.');
    return data.whereType<Map<String, dynamic>>()
        .map((item) => item['show'])
        .whereType<Map<String, dynamic>>()
        .map(TvShow.fromJson).toList();
  }

  Future<TvShow> getShow(int id) async {
    final data = await _get('/shows/$id');
    if (data is! Map<String, dynamic>) throw TvMazeException('Show details were not available.');
    return TvShow.fromJson(data);
  }

  Future<List<CastMember>> getCast(int id) async {
    final data = await _get('/shows/$id/cast');
    if (data is! List) return [];
    return data.whereType<Map<String, dynamic>>().map(CastMember.fromJson).toList();
  }

  Future<List<TvEpisode>> getEpisodes(int id) async {
    final data = await _get('/shows/$id/episodes');
    if (data is! List) return [];
    return data.whereType<Map<String, dynamic>>().map(TvEpisode.fromJson).toList();
  }
}
