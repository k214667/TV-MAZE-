import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'data/tvmaze_repository.dart';
import 'logic/shows_bloc.dart';
import 'logic/search_bloc.dart';
import 'logic/details_bloc.dart';
import 'logic/watchlist_cubit.dart';
import 'ui/app_shell.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  final repository = TvMazeRepository();
  runApp(TvMazeApp(repository: repository));
}

class TvMazeApp extends StatelessWidget {
  const TvMazeApp({super.key, required this.repository});
  final TvMazeRepository repository;

  @override
  Widget build(BuildContext context) {
    return MultiRepositoryProvider(
      providers: [
        RepositoryProvider.value(value: repository),
      ],
      child: MultiBlocProvider(
        providers: [
          BlocProvider(create: (_) => ShowsBloc(repository)..add(const ShowsRequested())),
          BlocProvider(create: (_) => SearchBloc(repository)),
          BlocProvider(create: (_) => WatchlistCubit()..load()),
        ],
        child: MaterialApp(
          title: 'TVMaze Explorer',
          debugShowCheckedModeBanner: false,
          theme: ThemeData(
            brightness: Brightness.dark,
            scaffoldBackgroundColor: const Color(0xFF0B0D16),
            colorScheme: ColorScheme.fromSeed(
              seedColor: const Color(0xFF8057FF),
              brightness: Brightness.dark,
              surface: const Color(0xFF151827),
            ),
            useMaterial3: true,
            appBarTheme: const AppBarTheme(
              backgroundColor: Color(0xFF0B0D16),
              surfaceTintColor: Colors.transparent,
            ),
            inputDecorationTheme: InputDecorationTheme(
              filled: true,
              fillColor: const Color(0xFF1C2032),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(16),
                borderSide: BorderSide.none,
              ),
            ),
          ),
          home: const AppShell(),
        ),
      ),
    );
  }
}
